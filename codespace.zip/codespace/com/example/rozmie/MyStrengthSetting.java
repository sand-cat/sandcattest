// Source code is decompiled from a .class file using FernFlower decompiler.
package com.example.rozmie;

public class MyStrengthSetting {
   private boolean[] prmInv;
   private int strength;

   public MyStrengthSetting(boolean[] prmInv, int strength) {
      this.prmInv = prmInv;
      this.strength = strength;
   }

   public boolean[] getParameterInvolve() {
      return this.prmInv;
   }

   public int getStrength() {
      return this.strength;
   }
}
